from app.dsd.parser import extract_requirements

def test_provider_requirements():
    doc = {
        "paragraphs": [
            {"type": "paragraph", "index": 1, "text": "Action Code equal to Add"},
            {"type": "paragraph", "index": 2, "text": "The System bypasses the record."},
        ],
        "tables": [],
    }
    reqs = extract_requirements(doc)
    ids = {r.requirement_id for r in reqs}
    assert "REQ-001" in ids
    assert "REQ-014" in ids
