# AI ETL SQL Test Case Generator

DSD-driven SQL test-case generation for Informatica PowerCenter ETL development.

## Architecture

DOCX DSD
-> DSD parser
-> structured requirements
-> semantic chunks
-> BGE embeddings
-> ChromaDB
-> Groq retrieval/planning
-> SQL test generation
-> deterministic validation
-> Excel/JSON output

The implementation is deliberately conservative:
- It does not invent database tables/columns that are absent from the DSD.
- Missing information is marked as `INSUFFICIENT_DSD_INFORMATION`.
- Every generated test keeps DSD references and requirement IDs.
- SQL is generated as a validation template when executable key/test-data details are not specified.

## Current DSD focus

The supplied document contains the Provider Common License flow, including UC-PRV-INT-10.1. The relevant DSD describes:
- Common License data being read and Provider License data being updated.
- Action Code branching, including Action Code A being bypassed.
- SSN/FEIN-specific rules.
- Source-to-target specifications.
- Date conversion/mapping.
- Issuing-agency lookup/derivation.
- Report/error behavior.

## Setup

1. Create a virtual environment.
2. Install requirements:
   `pip install -r requirements.txt`
3. Create `.env` from `.env.example`.
4. Put the DSD DOCX in `data/input/`.
5. Run:
   `python -m app.pipeline --input data/input/Interfaces_Part_Y.docx --use-case UC-PRV-INT-10.1`

Outputs:
- `data/output/requirements.json`
- `data/output/test_cases.json`
- `data/output/test_cases.xlsx`

## Important

Before executing generated SQL against Oracle, supply the real physical table names, keys, and test-data parameters in the DSD/configuration. The generator intentionally avoids guessing them.
