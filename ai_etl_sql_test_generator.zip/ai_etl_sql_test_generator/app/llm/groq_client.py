import json
from groq import Groq
from ..config import GROQ_API_KEY, GROQ_MODEL

class GroqLLM:
    def __init__(self):
        if not GROQ_API_KEY:
            raise RuntimeError("GROQ_API_KEY is not configured.")
        if not GROQ_MODEL:
            raise RuntimeError("GROQ_MODEL is not configured.")
        self.client = Groq(api_key=GROQ_API_KEY)

    def json_completion(self, system: str, user: str) -> dict:
        response = self.client.chat.completions.create(
            model=GROQ_MODEL,
            temperature=0,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        return json.loads(response.choices[0].message.content)
