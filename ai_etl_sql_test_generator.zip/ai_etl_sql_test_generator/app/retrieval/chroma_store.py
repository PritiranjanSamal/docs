import chromadb

class ChromaStore:
    def __init__(self, path: str, collection_name: str):
        client = chromadb.PersistentClient(path=path)
        self.collection = client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )

    def upsert_requirements(self, requirements, embeddings):
        ids = [r.requirement_id for r in requirements]
        docs = [r.source_text for r in requirements]
        metas = [
            {
                "requirement_id": r.requirement_id,
                "use_case_id": r.use_case_id,
                "category": r.category,
                "target_table": r.target_table or "",
                "target_columns": ",".join(r.target_columns),
                "dsd_reference": r.dsd_reference,
            }
            for r in requirements
        ]
        self.collection.upsert(ids=ids, documents=docs, embeddings=embeddings, metadatas=metas)

    def search(self, query: str, embedding: list[float], top_k: int = 8):
        return self.collection.query(
            query_embeddings=[embedding],
            n_results=top_k,
        )
