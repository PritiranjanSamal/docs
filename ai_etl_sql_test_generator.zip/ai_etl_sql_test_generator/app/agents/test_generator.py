from ..schemas import Requirement, TestCase
from ..llm.groq_client import GroqLLM

SYSTEM_PROMPT = """
You are an Informatica PowerCenter ETL QA test designer.

Your task is to generate SQL-based database validation test cases ONLY from
the supplied DSD requirements.

Hard rules:
1. Never invent table names, columns, keys, source values, target values,
   transformation rules, or business rules.
2. If an executable SQL predicate cannot be constructed from DSD-supported
   information, generate a safe SQL TEMPLATE using bind variables and put
   INSUFFICIENT_DSD_INFORMATION in notes.
3. Prefer source-to-target reconciliation, before/after comparison,
   conditional-path, lookup, date-conversion, null/conditional, and
   report-count tests when the DSD supports them.
4. Each test must trace to exactly one requirement.
5. Return JSON only.
"""

def generate_tests(llm: GroqLLM, req: Requirement, context: str) -> list[TestCase]:
    prompt = f"""
DSD REQUIREMENT:
{req.model_dump_json(indent=2)}

RETRIEVED DSD CONTEXT:
{context}

Generate a small but complete set of SQL test cases for this requirement.
Use bind variables such as :license_no, :process_date when the DSD does not
provide actual test data.

Return:
{{
  "test_cases": [
    {{
      "test_case_id": "temporary-id",
      "requirement_id": "{req.requirement_id}",
      "use_case_id": "{req.use_case_id}",
      "test_type": "...",
      "scenario": "...",
      "preconditions": [],
      "test_data": {{}},
      "execution_steps": [],
      "validation_sql": "...",
      "expected_result": "...",
      "priority": "HIGH|MEDIUM|LOW",
      "dsd_reference": "{req.dsd_reference}",
      "confidence": 0.0,
      "status": "GENERATED",
      "notes": []
    }}
  ]
}}
"""
    data = llm.json_completion(SYSTEM_PROMPT, prompt)
    tests = []
    for i, item in enumerate(data.get("test_cases", []), start=1):
        item["test_case_id"] = f"{req.requirement_id}-TC{i:02d}"
        item["requirement_id"] = req.requirement_id
        item["use_case_id"] = req.use_case_id
        item["dsd_reference"] = req.dsd_reference
        tests.append(TestCase.model_validate(item))
    return tests
