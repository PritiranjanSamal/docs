import re
from ..schemas import TestCase, Requirement

SQL_TABLE_RE = re.compile(r"\b(?:FROM|JOIN|UPDATE|INTO|DELETE\s+FROM)\s+([A-Z][A-Z0-9_$#.]*)", re.I)

def validate_test_case(tc: TestCase, req: Requirement) -> TestCase:
    sql = tc.validation_sql.upper()

    if "INSUFFICIENT_DSD_INFORMATION" in " ".join(tc.notes).upper():
        tc.status = "REVIEW_REQUIRED"

    if not tc.validation_sql.strip():
        tc.status = "REVIEW_REQUIRED"
        tc.notes.append("Empty validation SQL.")

    # Conservative hallucination check for target table.
    if req.target_table:
        referenced = [x.upper() for x in SQL_TABLE_RE.findall(sql)]
        # We don't fail if the SQL uses a bind/template, but flag unexplained physical tables.
        allowed = {req.target_table.upper(), "R_VV_TB", "DUAL"}
        unknown = [x for x in referenced if x not in allowed]
        if unknown:
            tc.status = "REVIEW_REQUIRED"
            tc.notes.append(f"SQL references tables not supported by this requirement: {unknown}")

    if tc.confidence < 0.75:
        tc.status = "REVIEW_REQUIRED"
        tc.notes.append("LLM confidence below 0.75; manual QA review recommended.")

    return tc
