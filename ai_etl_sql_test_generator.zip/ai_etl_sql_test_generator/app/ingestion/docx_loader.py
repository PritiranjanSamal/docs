from pathlib import Path
from docx import Document

def load_docx(path: str) -> dict:
    doc = Document(path)

    paragraphs = []
    for i, p in enumerate(doc.paragraphs, start=1):
        text = " ".join(p.text.split())
        if text:
            paragraphs.append({"type": "paragraph", "index": i, "text": text})

    tables = []
    for ti, table in enumerate(doc.tables, start=1):
        rows = []
        for row in table.rows:
            rows.append([" ".join(cell.text.split()) for cell in row.cells])
        tables.append({"type": "table", "index": ti, "rows": rows})

    return {
        "file": str(Path(path)),
        "paragraphs": paragraphs,
        "tables": tables,
    }
