import re
from .schemas import Requirement

USE_CASE = "UC-PRV-INT-10.1"

def _text(doc: dict) -> str:
    parts = [x["text"] for x in doc["paragraphs"]]
    for t in doc["tables"]:
        for row in t["rows"]:
            parts.append(" | ".join(row))
    return "\n".join(parts)

def _has(text, *terms):
    low = text.lower()
    return all(t.lower() in low for t in terms)

def extract_requirements(doc: dict, use_case_id: str = USE_CASE) -> list[Requirement]:
    """
    DSD-specific deterministic extraction for the supplied Provider Common License DSD.
    This is intentionally conservative. LLM extraction can be added later for other DSD formats.
    """
    text = _text(doc)
    reqs = []

    def add(rid, cat, src, target, rule, expected, ref, source_text):
        reqs.append(Requirement(
            requirement_id=rid,
            use_case_id=use_case_id,
            category=cat,
            source_fields=src,
            target_table=target,
            target_columns=target if isinstance(target, list) else [],
            rule=rule,
            expected_behavior=expected,
            dsd_reference=ref,
            source_text=source_text,
        ))

    add(
        "REQ-001", "ACTION_CODE", ["ACTION-CODE"], "P_CMN_LIC_UPLOAD_T",
        "If Action Code is 'A', the system bypasses the record.",
        "No Provider License update should be performed for the bypassed record.",
        "UC-PRV-INT-10.1 / Alternate Flow 1",
        "Action Code equal to Add: the System bypasses the record."
    )

    add(
        "REQ-002", "ACTION_CODE", ["ACTION-CODE"], "P_CMN_LIC_UPLOAD_T",
        "If Action Code is not 'A', processing continues to update the Provider License table.",
        "The record proceeds to update processing.",
        "UC-PRV-INT-10.1 / Basic Flow Steps 3-4",
        "If Action Code not equal to 'A' go to Basic Flow Step 4; update Provider License table."
    )

    mappings = [
        ("REQ-003", "LICENSE_NUMBER", ["LICENSE-NO"], "P_LIC_CERT_NUM",
         "LICENSE-NO maps to P_LIC_CERT_NUM.", "Target license number equals source license number.", "34.3.81.2.2"),
        ("REQ-004", "FIRST_NAME", ["FIRST-NAME"], "P_CMN_LIC_FIRST_NAME",
         "FIRST-NAME maps to P_CMN_LIC_FIRST_NAME.", "Target first name equals source first name.", "34.3.81.2.2"),
        ("REQ-005", "LAST_NAME", ["LAST-NAME"], "P_CMN_LIC_LAST_NAME",
         "LAST-NAME maps to P_CMN_LIC_LAST_NAME.", "Target last name equals source last name.", "34.3.81.2.2"),
        ("REQ-006", "MIDDLE_NAME", ["MIDDLE-NAME"], "P_CMN_LIC_MID_NAME",
         "MIDDLE-NAME maps to P_CMN_LIC_MID_NAME.", "Target middle name equals source middle name.", "34.3.81.2.2"),
        ("REQ-007", "PROFESSION", ["PROFESSION-ID"], "P_LIC_CERT_CD",
         "PROFESSION-ID maps to P_LIC_CERT_CD.", "Target profession/license code equals source profession ID.", "34.3.81.2.2"),
        ("REQ-008", "EFFECTIVE_DATE", ["EFFECTIVE-DATE"], "P_CMN_LIC_CERT_BEG_DT",
         "Effective date is converted from the source character date into the target DATE field.", "Target begin date represents the source effective date.", "34.3.81.2.2"),
        ("REQ-009", "EXPIRATION_DATE", ["EXPIRATION-DATE"], "P_CMN_LIC_CERT_END_DT",
         "Expiration date is converted into the target end-date field.", "Target end date represents the source expiration date.", "34.3.81.2.2"),
        ("REQ-010", "RESTRICTION", ["DISCIPLINARY-ACTION-INDICATOR"], "P-LIC-CERT-RSTRCT-CD",
         "Disciplinary-action indicator maps to the license restriction code.", "Target restriction code follows the DSD mapping/valid-value rule.", "34.3.80.2.2"),
        ("REQ-011", "LICENSE_STATUS", ["LICENSE-STATUS"], "P-CMN-LIC-CERT-STAT-CD",
         "License status is mapped to the common-license status code; the DSD specifies defaulting behavior for the target.", "Target license status follows the DSD specification.", "34.3.80.2.2"),
        ("REQ-012", "FACILITY_NAME", ["FACILITY NAME"], "P-CMN-LIC-CERT-FACI-NAM",
         "Facility name maps to the target facility-name field.", "Target facility name equals source facility name.", "34.3.80.2.2"),
    ]
    for rid, cat, src, target, rule, expected, ref in mappings:
        add(rid, cat, src, target, rule, expected, ref, f"{src[0]} -> {target}: {rule}")

    add(
        "REQ-013", "SSN_FEIN", ["SSN-FEIN"], "P_CMN_LIC_SSN_NUM",
        "Execute common SSN/FEIN rules for both; if SSN is present execute the SSN-specific rules; if FEIN is present execute the FEIN-specific rules.",
        "The applicable identifier path is processed according to the DSD and associated rule IDs.",
        "UC-PRV-INT-10.1 Business Rules",
        "Rules are executed for both SSN/FEIN. If SSN is present, SSN rules execute. If FEIN is present, FEIN rules execute."
    )

    add(
        "REQ-014", "ISSUING_AGENCY", ["ISSUING-AGENCY"], "P_LIC_CERT_AGCY_CD",
        "Set agency code to R_VV_TB.R_VV_CD where R_VV_TB.R_VV_DOMAIN_NAM = 'DM_OPLC_LIC_AGCY_CD' and R_VV_LONG_DESC matches the ISSUING-AGENCY value.",
        "Target agency code equals the valid-value code derived from R_VV_TB.",
        "34.3.80.2.2",
        "Derived: Set to R_VV_TB.R_VV_CD where R_VV_TB.R_VV_DOMAIN_NAM = DM_OPLC_LIC_AGCY_CD and R_VV_LONG_DESC like ISSUING-AGENCY."
    )

    add(
        "REQ-015", "FEIN", ["FEIN"], "P_CMN_LIC_FEIN_NUM",
        "FEIN is conditionally populated in P_CMN_LIC_FEIN_NUM.",
        "When FEIN is applicable, the target FEIN follows the DSD rule.",
        "34.3.80.2.2",
        "FEIN -> P_CMN_LIC_FEIN_NUM, required edit C."
    )

    add(
        "REQ-016", "REPORTING", [], "P_RPT_PROV_LIC_IFACE_UPD_TB",
        "The update report records the total number of records updated by the daily interface.",
        "Report total equals the number of records updated by the interface.",
        "PRV-INT-009",
        "Total Records Processed: total number of records updated in the database."
    )

    add(
        "REQ-017", "ERROR_HANDLING", [], None,
        "Database/read/write errors use error message 34-9999-0004 according to the exception flows.",
        "The appropriate error is recorded/generated when the specified exception occurs.",
        "UC-PRV-INT-10.1 Exception Flows",
        "Error Writing to Database, Error Reading Record, and Error Reading Database specify error message 34-9999-0004."
    )

    # Avoid accidental extraction from adjacent use cases.
    return reqs
