from typing import Any, Literal
from pydantic import BaseModel, Field

class Requirement(BaseModel):
    requirement_id: str
    use_case_id: str
    category: str
    source_fields: list[str] = Field(default_factory=list)
    target_table: str | None = None
    target_columns: list[str] = Field(default_factory=list)
    rule: str
    expected_behavior: str
    dsd_reference: str
    source_text: str
    explicit: bool = True

class TestCase(BaseModel):
    test_case_id: str
    requirement_id: str
    use_case_id: str
    test_type: str
    scenario: str
    preconditions: list[str] = Field(default_factory=list)
    test_data: dict[str, Any] = Field(default_factory=dict)
    execution_steps: list[str] = Field(default_factory=list)
    validation_sql: str
    expected_result: str
    priority: Literal["HIGH", "MEDIUM", "LOW"] = "MEDIUM"
    dsd_reference: str
    confidence: float = 0.0
    status: str = "GENERATED"
    notes: list[str] = Field(default_factory=list)
