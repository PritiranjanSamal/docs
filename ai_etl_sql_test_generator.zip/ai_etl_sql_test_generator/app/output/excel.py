from openpyxl import Workbook
from openpyxl.utils import get_column_letter

def write_excel(path: str, test_cases):
    wb = Workbook()
    ws = wb.active
    ws.title = "SQL Test Cases"

    headers = [
        "TC_ID","Requirement_ID","Use_Case","Test_Type","Scenario",
        "Preconditions","Test_Data","Execution_Steps","Validation_SQL",
        "Expected_Result","Priority","DSD_Reference","Confidence","Status","Notes"
    ]
    ws.append(headers)

    for tc in test_cases:
        ws.append([
            tc.test_case_id,
            tc.requirement_id,
            tc.use_case_id,
            tc.test_type,
            tc.scenario,
            "\n".join(tc.preconditions),
            str(tc.test_data),
            "\n".join(tc.execution_steps),
            tc.validation_sql,
            tc.expected_result,
            tc.priority,
            tc.dsd_reference,
            tc.confidence,
            tc.status,
            "\n".join(tc.notes),
        ])

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for col in range(1, ws.max_column + 1):
        ws.column_dimensions[get_column_letter(col)].width = min(
            max(14, max(len(str(ws.cell(r, col).value or "")) for r in range(1, ws.max_row + 1)) + 2),
            55
        )
    wb.save(path)
