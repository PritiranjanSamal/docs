import json
from pathlib import Path

def write_json(path: str, objects):
    Path(path).write_text(
        json.dumps([x.model_dump() for x in objects], indent=2, default=str),
        encoding="utf-8",
    )
