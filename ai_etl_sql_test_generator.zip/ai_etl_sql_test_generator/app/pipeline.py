import argparse
from pathlib import Path

from .config import EMBEDDING_MODEL, CHROMA_PATH, COLLECTION_NAME, TOP_K
from .ingestion.docx_loader import load_docx
from .dsd.parser import extract_requirements
from .retrieval.embeddings import BGEEmbedder
from .retrieval.chroma_store import ChromaStore
from .llm.groq_client import GroqLLM
from .agents.test_generator import generate_tests
from .agents.validator import validate_test_case
from .output.json import write_json
from .output.excel import write_excel

def run(input_path: str, use_case_id: str):
    out = Path("data/output")
    out.mkdir(parents=True, exist_ok=True)

    doc = load_docx(input_path)
    requirements = extract_requirements(doc, use_case_id)

    write_json(out / "requirements.json", requirements)

    embedder = BGEEmbedder(EMBEDDING_MODEL)
    embeddings = embedder.embed_documents([
        f"{r.category} {r.rule} {r.expected_behavior} {r.source_text}"
        for r in requirements
    ])

    store = ChromaStore(CHROMA_PATH, COLLECTION_NAME)
    store.upsert_requirements(requirements, embeddings)

    llm = GroqLLM()
    all_tests = []

    for req in requirements:
        query = f"{req.category} {req.rule} {req.expected_behavior} {req.dsd_reference}"
        qemb = embedder.embed_query(query)
        result = store.search(query, qemb, TOP_K)

        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        context = "\n\n".join(
            f"[{m.get('requirement_id')}] {d} | DSD: {m.get('dsd_reference')}"
            for d, m in zip(docs, metas)
        )

        tests = generate_tests(llm, req, context)
        tests = [validate_test_case(t, req) for t in tests]
        all_tests.extend(tests)

    write_json(out / "test_cases.json", all_tests)
    write_excel(out / "test_cases.xlsx", all_tests)

    print(f"Requirements: {len(requirements)}")
    print(f"Test cases:   {len(all_tests)}")
    print(f"Excel:        {out / 'test_cases.xlsx'}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--use-case", default="UC-PRV-INT-10.1")
    args = parser.parse_args()
    run(args.input, args.use_case)
